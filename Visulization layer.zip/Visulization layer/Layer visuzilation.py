from keras.models import load_model
import cv2
import numpy as np
import matplotlib.pyplot as plt
import os
from keras.models import Model


img=cv2.resize(cv2.imread('/home/ashrafi/Documents/Shetu mam/final dataset/df/ISIC_0024386.jpg.jpg'),(32,32))
model=load_model('/home/ashrafi/Documents/Shetu mam/acc8299shetu.h5')

model.summary()

output_layers=[layer.output for layer in model.layers]
activation_model=Model(inputs=model.input, output=output_layers)
activations=activation_model.predict(img.reshape(1,32,32,3))

def display_activation(activations, col_size, row_size, act_index):
    activation = activations[act_index]
    activation_index=0
    fig, ax = plt.subplots(row_size, col_size, figsize=(row_size*2.5,col_size*1.5))
    for row in range(0,row_size):
        for col in range(0,col_size):
            ax[row][col].imshow(activation[0, :, :, activation_index], cmap='gray')
            activation_index += 1
    plt.show()
for i in range(12):
    display_activation(activations, 8, 8, i)




